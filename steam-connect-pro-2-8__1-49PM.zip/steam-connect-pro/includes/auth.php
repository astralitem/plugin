<?php
if (!defined('ABSPATH')) exit;

/**
 * Shortcode: [steam_connect_button]
 * Steam connect / profile / disconnect
 */
function scp_steam_connect_shortcode() {

    $is_logged_in = is_user_logged_in();
    $user_id  = get_current_user_id();
    $steam_id = $user_id ? get_user_meta($user_id, 'steam_id', true) : '';

    $current_url = esc_url(home_url(add_query_arg([], $_SERVER['REQUEST_URI'])));

    $openid_params = [
        'openid.ns'         => 'http://specs.openid.net/auth/2.0',
        'openid.mode'       => 'checkid_setup',
        'openid.return_to'  => home_url('/steam-auth-callback') . '?redirect=' . urlencode($current_url),
        'openid.realm'      => home_url(),
        'openid.identity'   => 'http://specs.openid.net/auth/2.0/identifier_select',
        'openid.claimed_id' => 'http://specs.openid.net/auth/2.0/identifier_select',
    ];

    $openid_url = 'https://steamcommunity.com/openid/login?' . http_build_query($openid_params);

    ob_start();
    ?>
    <div class="scp-box">

        <?php if ($is_logged_in && $steam_id) :
            $steam_user = scp_get_steam_user_info($steam_id);
            if ($steam_user) : ?>

                <!-- TOP BAR -->
                <div class="scp-top-bar">
                    <div class="scp-success">
                        <span class="scp-check">✔</span>
                        <span>Steam Connected</span>
                    </div>

                    <form method="POST" action="<?php echo esc_url(admin_url('admin-post.php')); ?>">
                        <input type="hidden" name="action" value="scp_disconnect_steam">
                        <?php wp_nonce_field('scp_disconnect_action', 'scp_disconnect_nonce'); ?>
                        <button type="submit" class="scp-btn scp-btn-danger scp-btn-sm">
                            Disconnect
                        </button>
                    </form>
                </div>

                <!-- PROFILE -->
                <div class="scp-profile">
                    <img src="<?php echo esc_url($steam_user['avatar']); ?>" class="scp-avatar" alt="">
                    <div class="scp-info">
                        <strong><?php echo esc_html($steam_user['name']); ?></strong>
                        <span>Steam Level: <?php echo intval($steam_user['level']); ?></span>
                        <a href="<?php echo esc_url($steam_user['profile_url']); ?>" target="_blank">
                            View Steam Profile →
                        </a>
                    </div>
                </div>

            <?php endif; ?>

        <?php elseif ($is_logged_in) : ?>

            <a href="<?php echo esc_url($openid_url); ?>" class="scp-btn scp-btn-steam">
                Connect Steam Account
            </a>

        <?php else : ?>

            <a href="<?php echo esc_url(wp_login_url($current_url)); ?>" class="scp-btn scp-btn-login">
                Login to connect Steam
            </a>

        <?php endif; ?>

    </div>
    <?php
    return ob_get_clean();
}
add_shortcode('steam_connect_button', 'scp_steam_connect_shortcode');


/**
 * OpenID callback handling with verification.
 * Verifies the OpenID response with Steam before trusting the steamid.
 */
add_action( 'init', function () {
    if (
        isset( $_GET['openid_mode'] ) &&
        $_GET['openid_mode'] === 'id_res' &&
        strpos( $_SERVER['REQUEST_URI'], '/steam-auth-callback' ) !== false &&
        isset( $_GET['openid_claimed_id'] )
    ) {
        // Collect the incoming params for verification
        // Collect OpenID params and convert underscores back to dots
$verify_params = [];

foreach ( $_GET as $key => $value ) {
    if ( strpos( $key, 'openid_' ) === 0 ) {
        $new_key = str_replace( 'openid_', 'openid.', $key );
        $verify_params[ $new_key ] = wp_unslash( $value );
    }
}

// Validate claimed_id
if (
    empty( $verify_params['openid.claimed_id'] ) ||
    ! preg_match( '#^https?://steamcommunity.com/openid/id/(\d+)$#', $verify_params['openid.claimed_id'], $matches )
) {
    wp_safe_redirect( home_url( '/?steam_error=1' ) );
    exit;
}

// Force OpenID verification
$verify_params['openid.mode'] = 'check_authentication';

$response = wp_remote_post(
    'https://steamcommunity.com/openid/login',
    [
        'body'    => $verify_params,
        'timeout' => 10,
    ]
);

        if ( is_wp_error( $response ) ) {
            wp_safe_redirect( home_url( '/?steam_error=1' ) );
            exit;
        }

        $body = wp_remote_retrieve_body( $response );

        // Look for is_valid:true in response
        if ( strpos( $body, 'is_valid:true' ) === false ) {
            wp_safe_redirect( home_url( '/?steam_error=1' ) );
            exit;
        }

        // Extract steam id and save for current user
        $steam_id = $matches[1];
        $current_user_id = get_current_user_id();

        if ( $current_user_id && $steam_id ) {
            update_user_meta( $current_user_id, 'steam_id', sanitize_text_field( $steam_id ) );
            $redirect_url = isset( $_GET['redirect'] ) ? esc_url_raw( wp_unslash( $_GET['redirect'] ) ) : home_url( '/?steam_connected=1' );
            wp_safe_redirect( $redirect_url );
            exit;
        } else {
            wp_safe_redirect( home_url( '/?steam_error=1' ) );
            exit;
        }
    }
} );

/**
 * Disconnect handler
 */
add_action( 'admin_post_scp_disconnect_steam', 'scp_handle_disconnect' );
add_action( 'admin_post_nopriv_scp_disconnect_steam', 'scp_handle_disconnect' );

function scp_handle_disconnect() {
    if ( ! is_user_logged_in() || ! check_admin_referer( 'scp_disconnect_action', 'scp_disconnect_nonce' ) ) {
        wp_safe_redirect( home_url( '/?steam_disconnect_error=1' ) );
        exit;
    }

    $user_id = get_current_user_id();
    delete_user_meta( $user_id, 'steam_id' );

    wp_safe_redirect( home_url( '/?steam_disconnected=1' ) );
    exit;
}