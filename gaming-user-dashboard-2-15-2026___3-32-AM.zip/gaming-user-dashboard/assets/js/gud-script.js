(function () {
  'use strict';


  function setupAvatarPreview() {
    var avatarInput = document.getElementById('gud_avatar_file');
    if (!avatarInput) return;

    avatarInput.addEventListener('change', function (event) {
      var file = event.target.files && event.target.files[0] ? event.target.files[0] : null;
      if (!file || !file.type || file.type.indexOf('image/') !== 0) return;

      var reader = new FileReader();
      reader.onload = function (loadEvent) {
        var previews = document.querySelectorAll('.gud-avatar-preview .gud-avatar-image, .gud-header-avatar .gud-avatar-image');
        previews.forEach(function (img) {
          if (img && img.tagName && img.tagName.toLowerCase() === 'img') {
            img.src = loadEvent.target.result;
          }
        });
      };
      reader.readAsDataURL(file);
    });
  }

  function setupTabs() {
    var menu = document.querySelector('[data-gud-menu]');
    if (!menu) {
      return;
    }

    var menuItems = menu.querySelectorAll('[data-gud-tab]');
    var tabs = document.querySelectorAll('[data-gud-content]');

    menuItems.forEach(function (item) {
      item.addEventListener('click', function () {
        var target = item.getAttribute('data-gud-tab');

        menuItems.forEach(function (mi) {
          mi.classList.remove('gud-active');
        });
        item.classList.add('gud-active');

        tabs.forEach(function (tab) {
          tab.classList.toggle('gud-tab-active', tab.getAttribute('data-gud-content') === target);
        });
      });
    });
  }

  function setupModals() {
    var openButtons = document.querySelectorAll('[data-gud-modal-open]');
    var closeButtons = document.querySelectorAll('[data-gud-modal-close]');

    function closeModal(modal) {
      if (!modal) return;
      modal.classList.remove('gud-modal-visible');
      modal.setAttribute('aria-hidden', 'true');
      document.body.classList.remove('gud-modal-opened');
    }

    function openModal(modal) {
      if (!modal) return;
      modal.classList.add('gud-modal-visible');
      modal.setAttribute('aria-hidden', 'false');
      document.body.classList.add('gud-modal-opened');
    }

    openButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        var key = button.getAttribute('data-gud-modal-open');
        openModal(document.getElementById('gud-modal-' + key));
      });
    });

    closeButtons.forEach(function (button) {
      button.addEventListener('click', function () {
        closeModal(button.closest('.gud-modal'));
      });
    });

    document.querySelectorAll('.gud-modal').forEach(function (modal) {
      modal.addEventListener('click', function (event) {
        if (event.target === modal) closeModal(modal);
      });
    });

    document.addEventListener('keydown', function (event) {
      if (event.key === 'Escape') {
        closeModal(document.querySelector('.gud-modal.gud-modal-visible'));
      }
    });
  }

  function setupVerificationForm() {
    var form = document.querySelector('[data-gud-verify-form]');
    if (!form) return;

    var submitBtn = form.querySelector('[data-gud-submit]');
    var fields = form.querySelectorAll('input[required]');
    var isEditable = form.getAttribute('data-gud-editable') === '1';

    function setFeedback(fieldId, message, valid) {
      var feedback = form.querySelector('[data-gud-feedback-for="' + fieldId + '"]');
      if (!feedback) return;
      feedback.textContent = message;
      feedback.classList.toggle('is-valid', !!valid);
      feedback.classList.toggle('is-invalid', !valid);
    }

    function validateFullName(field) {
      var fullName = field.value.trim();
      if (!fullName) {
        setFeedback(field.id, 'نام و نام خانوادگی الزامی است.', false);
        return false;
      }

      var parts = fullName.split(/\s+/).filter(Boolean);
      if (parts.length < 2) {
        setFeedback(field.id, 'نام و نام خانوادگی باید حداقل دو کلمه با فاصله باشد.', false);
        return false;
      }

      if (parts[0].length < 3 || parts[1].length < 3) {
        setFeedback(field.id, 'نام و نام خانوادگی باید هر کدام حداقل ۳ حرف باشند.', false);
        return false;
      }

      setFeedback(field.id, 'نام و نام خانوادگی قبول است.', true);
      return true;
    }

    function validateField(field) {
      var id = field.id;

      if (field.disabled) {
        setFeedback(id, '', true);
        return true;
      }

      if (id === 'gud_full_name') {
        return validateFullName(field);
      }

      if (id === 'gud_mobile') {
        var mobile = field.value.trim();
        if (!mobile) {
          setFeedback(id, 'شماره موبایل الزامی است.', false);
          return false;
        }
        if (!/^09\d{9}$/.test(mobile)) {
          setFeedback(id, 'شماره موبایل باید با 09 شروع شود و 11 رقم باشد.', false);
          return false;
        }
        setFeedback(id, 'شماره موبایل قبول است.', true);
        return true;
      }

      if (id === 'gud_id_cards') {
        var files = field.files || [];
        if (files.length !== 2) {
          setFeedback(id, 'دقیقاً 2 تصویر کارت ملی (پشت و رو) انتخاب کنید.', false);
          return false;
        }
        var oversized = Array.prototype.some.call(files, function (file) {
          return file.size > 5 * 1024 * 1024;
        });
        if (oversized) {
          setFeedback(id, 'حجم هر تصویر کارت ملی باید حداکثر 5 مگابایت باشد.', false);
          return false;
        }
        setFeedback(id, 'تصاویر قبول است.', true);
        return true;
      }

      if (id === 'gud_pledge_file') {
        if (!field.files || field.files.length !== 1) {
          setFeedback(id, 'آپلود تصویر تعهدنامه الزامی است.', false);
          return false;
        }
        if (field.files[0].size > 5 * 1024 * 1024) {
          setFeedback(id, 'حجم تصویر تعهدنامه باید حداکثر 5 مگابایت باشد.', false);
          return false;
        }
        setFeedback(id, 'تصویر تعهدنامه قبول است.', true);
        return true;
      }

      if (id === 'gud_accept_rules') {
        if (!field.checked) {
          setFeedback(id, 'پذیرش قوانین سایت الزامی است.', false);
          return false;
        }
        setFeedback(id, 'قوانین سایت قبول است.', true);
        return true;
      }

      if (!field.value.trim()) {
        setFeedback(id, 'این فیلد الزامی است.', false);
        return false;
      }

      setFeedback(id, 'مقدار فیلد قبول است.', true);
      return true;
    }

    function validateForm() {
      var allValid = true;
      fields.forEach(function (field) {
        if (!validateField(field)) allValid = false;
      });
      if (submitBtn) submitBtn.disabled = !isEditable || !allValid;
      return allValid;
    }

    fields.forEach(function (field) {
      field.addEventListener('input', function () {
        validateField(field);
        validateForm();
      });
      field.addEventListener('change', function () {
        validateField(field);
        validateForm();
      });
      if (field.disabled) {
        if (field.id === 'gud_full_name' && field.value) setFeedback(field.id, 'نام و نام خانوادگی ثبت شده است.', true);
        if (field.id === 'gud_mobile' && field.value) setFeedback(field.id, 'شماره موبایل ثبت شده است.', true);
        if (field.id === 'gud_accept_rules' && field.checked) setFeedback(field.id, 'قوانین سایت قبول است.', true);
      } else if (field.value || field.checked) {
        validateField(field);
      }
    });

    form.addEventListener('submit', function (event) {
      if (!validateForm()) event.preventDefault();
    });

    validateForm();
  }

  function setupSuccessToast() {
    var toast = document.querySelector('[data-gud-toast="success"]');
    if (!toast) return;

    setTimeout(function () {
      toast.classList.add('gud-toast-hide');
      setTimeout(function () {
        if (toast && toast.parentNode) {
          toast.parentNode.removeChild(toast);
        }
      }, 450);
    }, 5000);
  }

  document.addEventListener('DOMContentLoaded', function () {
    setupAvatarPreview();
    setupTabs();
    setupModals();
    setupVerificationForm();
    setupSuccessToast();
  });
})();
